package com.example.evento

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.evento.view.adapter.ViewPagerAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.container_toolbar)
        toolbar.apply {
            title = "EventO"
            setTitleTextColor(resources.getColor(R.color.white))
        }

        val fragmentAdapter = ViewPagerAdapter(
            supportFragmentManager
        )
        viewpager_main.adapter = fragmentAdapter
        tabs.setupWithViewPager(viewpager_main,true)
    }
}
