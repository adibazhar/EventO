package com.example.evento.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "events")
data class Events (

    var title:String,
    var date:String,
    var description:String,
    var favourites:Boolean = false
){
    @PrimaryKey(autoGenerate = true)
    var id:Int = 0
}