package com.example.evento.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.evento.data.model.Events
import com.example.evento.data.repositories.EventRepo

class EventViewModel(application: Application):AndroidViewModel(application) {

    private var repo: EventRepo = EventRepo(application)

    suspend fun insertEvent(events: Events){
        repo.insertEvent(events)
    }

    suspend fun updateEvent(events: Events){
        repo.updateEvent(events)
    }

    suspend fun deleteEvent(events: Events){
        repo.deleteEvent(events)
    }
     fun getAllEvents():LiveData<List<Events>>{
        return repo.getAllEvents()
    }

     fun getFavouritesEvent():LiveData<List<Events>>{
        return repo.getFavouritesEvents()
    }
}