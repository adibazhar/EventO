package com.example.evento.view


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager

import com.example.evento.R
import com.example.evento.data.EventViewModel
import com.example.evento.data.model.Events
import com.example.evento.view.adapter.EventAdapter
import kotlinx.android.synthetic.main.fragment_second_tab.*

/**
 * A simple [Fragment] subclass.
 */
class SecondTabFragment : Fragment() {

    private lateinit var eventAdapter: EventAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second_tab, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val eventViewModel = ViewModelProviders.of(this).get(EventViewModel::class.java)
        eventAdapter = EventAdapter()

        eventViewModel.getFavouritesEvent().observe(this, Observer {
            eventAdapter.submitList(it)
        })


        recycler_tab_two.apply {
            adapter = eventAdapter
            layoutManager = LinearLayoutManager(this.context)
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
      //  val items = listOf(Events("title 3","Feb","dsadasd"),Events("title 3","Feb","dsadasd"),Events("title 3","Feb","dsadasd"))

    }


}
