package com.example.evento

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import com.example.evento.view.ThirdTabFragment
import kotlinx.android.synthetic.main.activity_addupdate_event.*
import kotlinx.android.synthetic.main.toolbar.*

class AddUpdateActivity : AppCompatActivity() {

    val ADD_EVENT_REQUEST_CODE = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_addupdate_event)
        val toolbar = findViewById<Toolbar>(R.id.toolbar_main)

        val requestEvent = intent.getStringExtra(ThirdTabFragment.SEND_EVENT)
        if (requestEvent == ThirdTabFragment.EXTRA_ADD_EVENT){
            toolbar.title = "Add Event"
        }
        toolbar.apply {
            setTitleTextColor(resources.getColor(R.color.white))
            navigationIcon = getDrawable(R.drawable.ic_back_arrow_white)
        }
        setSupportActionBar(toolbar)

        toolbar.setNavigationOnClickListener { finish() }

//        button_submit.setOnClickListener {
//            addEvent()
//        }
    }

    private fun addEvent() {
        val eventTitle = editText_title.toString()
        val eventDate = spinner_date
    }


}
