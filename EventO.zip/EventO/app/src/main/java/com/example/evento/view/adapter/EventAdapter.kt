package com.example.evento.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.evento.R
import com.example.evento.data.model.Events
import kotlinx.android.synthetic.main.list_item_view.view.*

class EventAdapter :ListAdapter<Events,EventAdapter.EventViewHolder>(DiffCallback) {

    inner class EventViewHolder (itemView:View):RecyclerView.ViewHolder(itemView){
        val tv_title = itemView.tv_title
        val tv_date = itemView.tv_date
        val tv_description = itemView.tv_description

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.list_item_view,parent,false)
        return EventViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val currentEvent = getItem(position)
        holder.tv_title.text = currentEvent.title
        holder.tv_date.text = currentEvent.date
        holder.tv_description.text = currentEvent.description

    }

    companion object{
       private val DiffCallback = object : DiffUtil.ItemCallback<Events>() {

           override fun areItemsTheSame(oldItem: Events, newItem: Events): Boolean {
               return oldItem.id == newItem.id
           }

           override fun areContentsTheSame(oldItem: Events, newItem: Events): Boolean {
               return oldItem.title == newItem.title && oldItem.description == newItem.description
                       && oldItem.favourites == newItem.favourites
           }
       }
    }
}